import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc

# Database connection setup
server = 'DESKTOP-5SN87LB\\SQLEXPRESS'  # Replace with your server name
database = 'university_db'  # Replace with your database name
connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;'

try:
    conn = pyodbc.connect(connection_string)
    cursor = conn.cursor()
    print("Database connection successful!")
except pyodbc.Error as e:
    messagebox.showerror("Database Error", f"Error connecting to database: {e}")
    exit()

# Functions
def display_data(table_name):
    """Fetch and display data from a selected table."""
    try:
        query = f"SELECT * FROM {table_name}"
        cursor.execute(query)
        rows = cursor.fetchall()

        # Clear previous rows in the TreeView
        for row in tree_view.get_children():
            tree_view.delete(row)

        # Insert new rows into the TreeView
        for row in rows:
            tree_view.insert("", tk.END, values=row)

        # Update column headings dynamically
        columns = [column[0] for column in cursor.description]
        tree_view["columns"] = columns
        tree_view["show"] = "headings"

        for col in columns:
            tree_view.heading(col, text=col)
            tree_view.column(col, width=150)

        # Update delete button state
        delete_btn["state"] = tk.NORMAL
        delete_btn["command"] = lambda: delete_record(table_name, columns[0])

    except pyodbc.Error as e:
        messagebox.showerror("Database Error", f"Error fetching data: {e}")

def insert_student_data(st_id, st_phone, st_name, dob, ins_id):
    """Insert a new student into the STUDENT table."""
    try:
        query = """
        INSERT INTO STUDENT (ST_ID, ST_Phone, ST_Name, DateofBirth, INS_ID)
        VALUES (?, ?, ?, ?, ?)
        """
        values = (st_id, st_phone, st_name, dob, ins_id)
        cursor.execute(query, values)
        conn.commit()
        messagebox.showinfo("Success", "Student data inserted successfully!")
    except pyodbc.Error as e:
        messagebox.showerror("Database Error", f"Error inserting data: {e}")

def delete_record(table_name, primary_key_column):
    """Delete a record from the selected table."""
    selected_item = tree_view.selection()
    if not selected_item:
        messagebox.showwarning("Warning", "No record selected!")
        return

    try:
        record = tree_view.item(selected_item)
        primary_key_value = record['values'][0]
        query = f"DELETE FROM {table_name} WHERE {primary_key_column} = ?"
        cursor.execute(query, primary_key_value)
        conn.commit()
        tree_view.delete(selected_item)
        messagebox.showinfo("Success", "Record deleted successfully!")
    except pyodbc.Error as e:
        messagebox.showerror("Database Error", f"Error deleting record: {e}")

# GUI Setup
root = tk.Tk()
root.title("University Database Management")
root.geometry("900x600")

# Buttons for different tables
buttons_frame = tk.Frame(root)
buttons_frame.pack(fill=tk.X, pady=10)

tables = ["DEPARTMENT", "COURSE", "INSTRUCTOR", "REG", "SECTION", "STUDENT", "ADVICES"]
for table in tables:
    btn = tk.Button(buttons_frame, text=f"Show {table}", command=lambda t=table: display_data(t))
    btn.pack(side=tk.LEFT, padx=5)

# Form for inserting new student
form_frame = tk.LabelFrame(root, text="Insert New Student", padx=10, pady=10)
form_frame.pack(fill=tk.X, pady=10)

tk.Label(form_frame, text="Student ID").grid(row=0, column=0)
st_id_entry = tk.Entry(form_frame)
st_id_entry.grid(row=0, column=1)

tk.Label(form_frame, text="Phone").grid(row=0, column=2)
st_phone_entry = tk.Entry(form_frame)
st_phone_entry.grid(row=0, column=3)

tk.Label(form_frame, text="Name").grid(row=1, column=0)
st_name_entry = tk.Entry(form_frame)
st_name_entry.grid(row=1, column=1)

tk.Label(form_frame, text="Date of Birth (YYYY-MM-DD)").grid(row=1, column=2)
dob_entry = tk.Entry(form_frame)
dob_entry.grid(row=1, column=3)

tk.Label(form_frame, text="Instructor ID").grid(row=2, column=0)
ins_id_entry = tk.Entry(form_frame)
ins_id_entry.grid(row=2, column=1)

insert_btn = tk.Button(
    form_frame,
    text="Insert Student",
    command=lambda: insert_student_data(
        st_id_entry.get(),
        st_phone_entry.get(),
        st_name_entry.get(),
        dob_entry.get(),
        ins_id_entry.get(),
    ),
)
insert_btn.grid(row=2, column=2, columnspan=2)

# TreeView for displaying data
tree_view = ttk.Treeview(root)
tree_view.pack(fill=tk.BOTH, expand=True)

# Delete button
delete_btn = tk.Button(root, text="Delete Selected Record", state=tk.DISABLED)
delete_btn.pack(pady=10)

# Run the GUI loop
root.mainloop()
