-- Get all departments
SELECT * FROM DEPARTMENT;

-- Get all courses
SELECT * FROM COURSE;

-- Get all instructors
SELECT * FROM INSTRUCTOR;

-- Get all registrations
SELECT * FROM REG;

-- Get all sections
SELECT * FROM SECTION;

-- Get all students
SELECT * FROM STUDENT;

-- Get all advising relationships
SELECT * FROM ADVICES;